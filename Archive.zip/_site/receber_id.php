<?php

file_put_contents('arquivo.txt', $_POST['id'] . "\n", FILE_APPEND);
